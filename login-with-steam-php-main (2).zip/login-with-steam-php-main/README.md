# login-with-steam-php
A simple login with Steam starter project using open ID and PHP

## Video Tutorial:
https://youtu.be/7IzEqAK_PLg

## Written Guide:
https://cindr.org/how-to-make-a-login-with-steam-button-with-php-oauth-open/

Some of this code was adapated from the following repository, especially the paramter building:
https://github.com/vikas5914/steam-auth
